<!-- client/src/views/SettingsView.vue -->
<template>
  <div class="settings">
    <h1>Настройки системы</h1>
    
    <div class="settings-grid">
      <div class="setting-card">
        <h3>Профиль пользователя</h3>
        <p>Настройки вашего аккаунта</p>
        <button>Перейти</button>
      </div>
      
      <div class="setting-card">
        <h3>Управление пользователями</h3>
        <p>Добавление и редактирование пользователей</p>
        <button>Перейти</button>
      </div>
      
      <div class="setting-card">
        <h3>Интеграции</h3>
        <p>Подключение маркетплейсов и платежных систем</p>
        <button>Перейти</button>
      </div>
      
      <div class="setting-card">
        <h3>Резервное копирование</h3>
        <p>Экспорт и импорт данных</p>
        <button>Перейти</button>
      </div>
    </div>
  </div>
</template>