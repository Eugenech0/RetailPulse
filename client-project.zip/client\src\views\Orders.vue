<!-- client/src/views/OrdersView.vue -->
<template>
  <div class="orders">
    <h1>Управление заказами</h1>
    
    <div class="filters">
      <select v-model="selectedStatus">
        <option value="all">Все статусы</option>
        <option v-for="status in orderStatuses" :key="status.value" :value="status.value">{{ status.text }}</option>
      </select>
      <input type="date" v-model="startDate">
      <input type="date" v-model="endDate">
      <button @click="applyFilters">Применить</button>
    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Клиент</th>
          <th>Дата</th>
          <th>Сумма</th>
          <th>Статус</th>
          <th>Действия</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="order in filteredOrders" :key="order.id">
          <td>#{{ order.id }}</td>
          <td>{{ order.customer }}</td>
          <td>{{ order.date }}</td>
          <td>{{ order.amount }} ₽</td>
          <td>
            <select v-model="order.status" @change="updateOrderStatus(order)">
              <option v-for="status in orderStatuses" :key="status.value" :value="status.value">{{ status.text }}</option>
            </select>
          </td>
          <td>
            <button @click="viewDetails(order)">Просмотр</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectedStatus: 'all',
      startDate: '',
      endDate: '',
      orderStatuses: [
        {value: 'new', text: 'Новый'},
        {value: 'processing', text: 'В обработке'},
        {value: 'shipped', text: 'Отправлен'},
        {value: 'delivered', text: 'Доставлен'},
        {value: 'cancelled', text: 'Отменен'}
      ],
      orders: [
        // Данные аналогичные Dashboard, но больше
      ]
    }
  },
  methods: {
    applyFilters() {
      // Фильтрация заказов
    },
    updateOrderStatus(order) {
      console.log(`Обновлен статус заказа #${order.id}: ${order.status}`);
    },
    viewDetails(order) {
      this.$router.push(`/order/${order.id}`);
    }
  }
}
</script>