<template>
  <div id="app">
    <header>
      <section>
        <h2>Retail Pulse</h2>
      </section>
      <nav>
        <ul>
          <li><a href="#"></a></li>
          <li><a href="#"></a></li>
          <li><a href="#"></a></li>
          <li><a href="#"></a></li>
        </ul>
      </nav>
    </header>
    <div class="content">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
</script>

<style>
  #app {
    background-color: rgb(110, 77, 77);
  }
</style>