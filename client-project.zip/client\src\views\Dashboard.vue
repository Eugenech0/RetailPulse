<!-- client/src/views/DashboardView.vue -->
<template>
  <div class="dashboard">
    <h1>Главная панель</h1>
    
    <div class="metrics">
      <div class="metric-card">
        <div class="metric-value">142</div>
        <div class="metric-label">Всего заказов</div>
      </div>
      <div class="metric-card">
        <div class="metric-value">24</div>
        <div class="metric-label">Новые заказы</div>
      </div>
      <div class="metric-card">
        <div class="metric-value">58</div>
        <div class="metric-label">Клиенты</div>
      </div>
    </div>

    <div class="recent-orders">
      <h2>Последние заказы</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Клиент</th>
            <th>Дата</th>
            <th>Сумма</th>
            <th>Статус</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="order in orders" :key="order.id">
            <td>#{{ order.id }}</td>
            <td>{{ order.customer }}</td>
            <td>{{ order.date }}</td>
            <td>{{ order.amount }} ₽</td>
            <td><span :class="['status', order.status]">{{ order.statusText }}</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      orders: [
        {id: 1025, customer: "Иван Петров", date: "2023-10-01", amount: 12400, status: "shipped", statusText: "Отправлен"},
        {id: 1024, customer: "Мария Сидорова", date: "2023-09-29", amount: 5600, status: "processing", statusText: "В обработке"},
        {id: 1023, customer: "Алексей Иванов", date: "2023-09-28", amount: 18900, status: "delivered", statusText: "Доставлен"}
      ]
    }
  }
}
</script>

<style scoped>
/* Общие стили добавьте в App.vue */
</style>