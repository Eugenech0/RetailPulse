<!-- client/src/views/CustomersView.vue -->
<template>
  <div class="customers">
    <h1>Управление клиентами</h1>
    
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Имя</th>
          <th>Email</th>
          <th>Телефон</th>
          <th>Заказов</th>
          <th>Общая сумма</th>
          <th>Действия</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="customer in customers" :key="customer.id">
          <td>{{ customer.id }}</td>
          <td>{{ customer.name }}</td>
          <td>{{ customer.email }}</td>
          <td>{{ customer.phone }}</td>
          <td>{{ customer.ordersCount }}</td>
          <td>{{ customer.totalSpent }} ₽</td>
          <td>
            <button @click="viewCustomer(customer)">Просмотр</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      customers: [
        {id: 1, name: "Иван Петров", email: "ivan@example.com", phone: "+7 999 123-45-67", ordersCount: 5, totalSpent: 54200},
        {id: 2, name: "Мария Сидорова", email: "maria@example.com", phone: "+7 912 345-67-89", ordersCount: 3, totalSpent: 16800},
        {id: 3, name: "Алексей Иванов", email: "alex@example.com", phone: "+7 987 654-32-10", ordersCount: 7, totalSpent: 120500}
      ]
    }
  },
  methods: {
    viewCustomer(customer) {
      this.$router.push(`/customer/${customer.id}`);
    }
  }
}
</script>