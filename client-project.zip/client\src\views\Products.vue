<!-- client/src/views/ProductsView.vue -->
<template>
  <div class="products">
    <div class="header">
      <h1>Управление товарами</h1>
      <button class="btn-add">+ Добавить товар</button>
    </div>

    <div class="controls">
      <input type="text" placeholder="Поиск товара..." v-model="searchQuery">
      <select v-model="selectedCategory">
        <option value="all">Все категории</option>
        <option v-for="category in categories" :key="category">{{ category }}</option>
      </select>
    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Название</th>
          <th>Категория</th>
          <th>Цена</th>
          <th>Остаток</th>
          <th>Действия</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="product in filteredProducts" :key="product.id">
          <td>{{ product.id }}</td>
          <td>{{ product.name }}</td>
          <td>{{ product.category }}</td>
          <td>{{ product.price }} ₽</td>
          <td>{{ product.stock }} шт.</td>
          <td>
            <button class="btn-edit">✏️</button>
            <button class="btn-delete">🗑️</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      searchQuery: '',
      selectedCategory: 'all',
      categories: ['Электроника', 'Одежда', 'Бытовая техника', 'Книги'],
      products: [
        {id: 1, name: "Ноутбук", category: "Электроника", price: 50000, stock: 10},
        {id: 2, name: "Смартфон", category: "Электроника", price: 30000, stock: 25},
        {id: 3, name: "Футболка", category: "Одежда", price: 1200, stock: 50},
        {id: 4, name: "Холодильник", category: "Бытовая техника", price: 45000, stock: 5}
      ]
    }
  },
  computed: {
    filteredProducts() {
      return this.products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(this.searchQuery.toLowerCase());
        const matchesCategory = this.selectedCategory === 'all' || product.category === this.selectedCategory;
        return matchesSearch && matchesCategory;
      });
    }
  }
}
</script>