<!-- client/src/views/AnalyticsView.vue -->
<template>
  <div class="analytics">
    <h1>Аналитика продаж</h1>
    
    <div class="charts">
      <div class="chart-container">
        <h3>Продажи по месяцам</h3>
        <div class="chart-placeholder">График продаж</div>
      </div>
      
      <div class="chart-container">
        <h3>Топ товаров</h3>
        <div class="chart-placeholder">График топ товаров</div>
      </div>
    </div>
    
    <div class="metrics">
      <div class="metric">
        <h4>Средний чек</h4>
        <p>5 840 ₽</p>
      </div>
      <div class="metric">
        <h4>Конверсия</h4>
        <p>4.2%</p>
      </div>
      <div class="metric">
        <h4>Повторные покупки</h4>
        <p>32%</p>
      </div>
    </div>
  </div>
</template>